<?php

if(isset($_POST['latitude']) && isset($_POST['longitude'])){

    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];

    echo "Localização recebida.<br>";

    echo "Latitude: $latitude <br>";
    echo "Longitude: $longitude <br>";

    // Exemplo: salvar em um arquivo
    file_put_contents(
        "localizacao.txt",
        "Latitude: $latitude | Longitude: $longitude\n",
        FILE_APPEND
    );
}
?>